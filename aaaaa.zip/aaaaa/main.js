document.addEventListener('DOMContentLoaded', function() {
    // القائمة المنسدلة للجووال
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
    const dropdowns = document.querySelectorAll('.dropdown');
    
    hamburger.addEventListener('click', function() {
        this.classList.toggle('active');
        navLinks.classList.toggle('active');
    });
    
    dropdowns.forEach(dropdown => {
        const link = dropdown.querySelector('a');
        
        link.addEventListener('click', function(e) {
            if (window.innerWidth <= 768) {
                e.preventDefault();
                dropdown.classList.toggle('active');
            }
        });
    });
    
    // عداد الإحصائيات
    const counters = document.querySelectorAll('.counter');
    const speed = 200;
    
    function animateCounters() {
        counters.forEach(counter => {
            const target = +counter.getAttribute('data-target');
            const count = +counter.innerText;
            const increment = target / speed;
            
            if (count < target) {
                counter.innerText = Math.ceil(count + increment);
                setTimeout(animateCounters, 1);
            } else {
                counter.innerText = target;
            }
        });
    }
    
    // تشغيل العداد عند التمرير للقسم
    const statsSection = document.querySelector('.stats');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounters();
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });
    
    observer.observe(statsSection);
    
    // تأثيرات الظهور عند التمرير
    const fadeElements = document.querySelectorAll('.feature-card, .team-card, .contact-info, .contact-form');
    
    const fadeObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
                fadeObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });
    
    fadeElements.forEach(element => {
        fadeObserver.observe(element);
    });
    
    // تغيير لون النافبار عند التمرير
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            document.querySelector('.navbar').style.backgroundColor = 'rgba(44, 26, 10, 0.95)';
            document.querySelector('.navbar').style.padding = '0.5rem 0';
        } else {
            document.querySelector('.navbar').style.backgroundColor = 'var(--dark-color)';
            document.querySelector('.navbar').style.padding = '1rem 0';
        }
    });
    
    // تأثيرات الصور في الهيرو
    const thumbnails = document.querySelectorAll('.thumbnail');
    const mainImage = document.querySelector('.main-image');
    
    thumbnails.forEach(thumbnail => {
        thumbnail.addEventListener('click', function() {
            // تبادل الصور
            const tempSrc = mainImage.src;
            mainImage.src = this.src;
            this.src = tempSrc;
            
            // تأثير الحركة
            mainImage.style.transform = 'scale(1.05)';
            setTimeout(() => {
                mainImage.style.transform = 'scale(1)';
            }, 300);
            document.addEventListener('DOMContentLoaded', function() {
    const thumbnails = document.querySelectorAll('.thumbnail');
    const mainImage = document.querySelector('.main-image');
    
    thumbnails.forEach(thumbnail => {
        thumbnail.addEventListener('click', function() {
            // تأثير التلاشي
            mainImage.style.opacity = '0';
            
            setTimeout(() => {
                // تبادل الصور
                const tempSrc = mainImage.src;
                mainImage.src = this.src;
                this.src = tempSrc;
                
                // تأثير الظهور
                mainImage.style.opacity = '1';
                
                // تأثير الحركة
                mainImage.parentElement.style.transform = 'scale(1.03)';
                setTimeout(() => {
                    mainImage.parentElement.style.transform = 'scale(1)';
                }, 300);
            }, 300);
            
            document.addEventListener('DOMContentLoaded', function() {
    const slides = document.querySelectorAll('.text-slide');
    let currentSlide = 0;
    
    // بدء الحركة التلقائية
    function startSlider() {
        setInterval(() => {
            // إخفاء الشريحة الحالية
            slides[currentSlide].classList.remove('active');
            slides[currentSlide].classList.add('prev');
            
            // الانتقال للشريحة التالية
            currentSlide = (currentSlide + 1) % slides.length;
            
            // إظهار الشريحة الجديدة
            setTimeout(() => {
                slides[currentSlide].classList.remove('prev');
                slides[currentSlide].classList.add('active');
            }, 100);
            
        }, 3000); // التبديل كل 3 ثواني
    }
    
    startSlider();
});
        });
    });
});